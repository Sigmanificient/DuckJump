Hi from the Sigmanificient Corp. !
Duck Jump is a game originally thought by a group of 4 persons,
including Marco Campanelli, Xavier Menard, ? and ? ( name is currenlty researched and will be added soon as possible ).
	This is the version 2.0 of the game, fully recreated by myself, Edhyjox with some optimisation as far as I could done.
It's still include a little bug of collision but I'm not an expert developper and this is one of my few released project yet.
if you want to contact me for more informations :
- Gmail : Edhyjox@gmail.com
- Discord : Edhyjox#1764

[Warning] The Duck Jump 2.exe is generated with Pyinstaller.
Since the author ( "Sigmanificient Corp.") is not validated, your antivirus can delete the executable.
Feel free to check yourself the source code whether your not confidant or a curious guy.
However, if you still can't trust the executable, you will have to install python to run the .py file.
This is the requirement :
- python 3.7.0 or highter
- pygame 1.9.6 or highter

Why the game run 90-100fps ?
This is due of two main raison :
- First, making a game that run same speed in any fps condition under pygame is way harder.
So we decide to limit the fps to something easily reachable by a lot of computer today.
With an fixed fps, the game should run about always the same speed.
- Moreover, having the maximal amount of fps is not the most useful thing since it will ask more processor ressources,
and a lot of minitor is still 60Hz.

Change the max fps value ?
If your an advenced user, you can change the fps value to whatever you want by replace the number 100 in clock.tick() function. ( .py ) file.
you will need the requirement ( see above ) and it could break the game.

My fps is below 90 ?
In this case, we unfortunate to say that we can do anything for this. Make sure you having only the application open and if the case, then your computer doesn't support our game.
We would be interressed to see that !

Pydroid compatible ?
No, unfortunately, there is sme function that make the pygame program uncompatible with pydroid.
Even it's would be, you'll need a very powerful phone to run it well.

"Failed to execute script" strange message showing up ?
This message can be if the executable is not compatible with your computer.
It have been made for windows 10 and could failed on windows 7 or 8.

Wanna share the game ?
You're be welcome for this help. Make sure mention the author for the work ^^ 

Modify/Optimise/Upload the game ?
Yes, you can ! Please respect the CC BY NA liscence and include this file in it !
We are not reponsable for any problem that could be cause by modification / problems occurs by running a modified verion of the game.

Other question / porblem ?
Don't worry to contact us and don't stay with something that your not sure of !